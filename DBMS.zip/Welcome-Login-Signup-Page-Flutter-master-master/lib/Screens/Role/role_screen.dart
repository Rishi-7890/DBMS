import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Role/components/body.dart';

class RoleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}