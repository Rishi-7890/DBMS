import 'package:flutter/material.dart';

class AwaitedRole extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Text(
            'Send an email on email@email.com with ur role , wiz doctor , patient , admin , nurse , to continue with login'),
      ),
    );
  }
}
